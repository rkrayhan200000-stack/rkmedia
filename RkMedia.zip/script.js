function playVideo(event) {
    var file = event.target.files[0];
    var video = document.getElementById("videoPlayer");
    video.src = URL.createObjectURL(file);
}

function playAudio(event) {
    var file = event.target.files[0];
    var audio = document.getElementById("audioPlayer");
    audio.src = URL.createObjectURL(file);
}